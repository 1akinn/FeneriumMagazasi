﻿<?php
//Oturum işlemlerinin yapılabilmesi için
session_start();
//$host = 'localhost';	//sunucu adı
$host = "localhost";	//sunucu adı
$database = "21645221002_db";	//veritabanı şemasının adı
$dbuser = "root";		//kullanıcı adı
$dbpass = "";		//parola
$dsn = "mysql:host=" . $host . ";dbname=" . $database . ";charset=utf8";
try { //parametrelere göre bir DSN nesnesi oluşturuluyor
	$pdo = new PDO($dsn, $dbuser, $dbpass);
	//PHP sayfalarında Türkçe karakterlerin görüntülenmesi için
	$pdo->exec("SET NAMES 'utf8'; SET CHARSET 'utf8'");
	//echo "Bağlantı Kuruldu<br>";
} catch (PDOException $e) {
	echo 'Connection failed: ' . $e->getMessage();
}

$yetki_ = 0;
$UID_ = 0;
//Eğer UID Session değişkeni varsa oturum açılmış demektir
if (isset($_SESSION["UID"])) {
	$sqlU = "SELECT * FROM uyeler WHERE UID = " . $_SESSION["UID"];
	$queryU = $pdo->query($sqlU);
	$rc = $queryU->rowCount();
	if ($rc == 1) {
		$rowU = $queryU->fetch(PDO::FETCH_ASSOC);
		extract($rowU);
		$UID_ = $rowU["UID"];
		$ad_soyad = $rowU["Ad"] . " " . $rowU["Soyad"];
		$yetki_ = $rowU["Yetki"];
	}
	$queryU->closeCursor();
}
