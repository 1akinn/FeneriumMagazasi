﻿<h1>Ürünler</h1>
<div class="row">
    <?php
    $sqlB = "SELECT * FROM blog WHERE 1 ORDER BY BID DESC";
    $queryB = $pdo->query($sqlB);
    $rc = $queryB->rowCount();
    foreach ($queryB as $rowB) {
        extract($rowB);
        $linkM = "index.php?pg=blog/blog_detay&bid={$BID}";
    ?>
        <div class="col-md-6 col-sm-12">
            <div class="card mb-3 p-2">
                <a class="linkA" href="<?php echo $linkM; ?>">
                    <div class="img1" style="background-image:url(<?php echo $Resim; ?>)">
                        <h4 class="hMain"><?php echo $Baslik ?></h4>
                    </div>
                    <div class="pt-3">
                        <?php echo substr($Icerik, 0, 120); ?>
                    </div>
                </a>
            </div>
        </div>
    <?php
    }
    $queryB->closeCursor();
    ?>
</div>