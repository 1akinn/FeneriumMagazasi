<?php
include "../dbconn.php";

if (isset($_POST["BID"])) {
    $BID = $_POST["BID"];
    $Baslik = addslashes(trim($_POST["Baslik"]));
    $Icerik = addslashes(trim($_POST["Icerik"]));

    if ($ID < 1) { //INSERT işlemi yapılacak
        $sqlG = "INSERT INTO blog SET ";
        $sqlG .= "UID = $UID_, ";
        $sqlG .= "Baslik = '$Baslik', ";
        $sqlG .= "Icerik = '$Icerik', ";
        $sqlG .= "CTarihi = NOW() ";
    } else {    //UPDATE işlemi yapılacak
        $sqlG = "UPDATE blog SET ";
        $sqlG .= "Baslik = '$Baslik', ";
        $sqlG .= "Icerik = '$Icerik', ";
        $sqlG .= "UTarihi = NOW() ";
        $sqlG .= "WHERE BID = " . $BID;
    }
    $queryG = $pdo->prepare($sqlG);
    $queryG->execute();
    echo "Sorgu :" . $sqlG;
} else if (isset($_GET["sil"])) {
    $sqlD = "DELETE FROM blog WHERE BID = " . $_GET["sil"];
    $queryD = $pdo->prepare($sqlD);
    $queryD->execute();
    echo "Sorgu :" . $sqlD;
}


$pdo = NULL;
?>
<script>
    window.history.back();
</script>