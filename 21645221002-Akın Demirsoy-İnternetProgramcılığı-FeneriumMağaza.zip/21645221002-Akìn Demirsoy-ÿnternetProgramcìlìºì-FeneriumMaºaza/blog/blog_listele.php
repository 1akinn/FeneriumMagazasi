﻿<h4>Ürün Listele</h4>
<?php
$sqlB = "SELECT * FROM blog WHERE UID = $UID_ ORDER BY BID DESC";
$queryB = $pdo->query($sqlB);
$rc = $queryB->rowCount();
echo "<h6> Kayıt Sayısı " . $rc . "</h6>";

foreach ($queryB as $rowB) {
    extract($rowB);
?>
    <div class="card p-0 mb-3">
        <div class="card-body p-2">
            <h5><?php echo $Baslik; ?></h5>
            <div class="row">
                <div class="col-md-4">
                    <?php
                    if (strlen($Resim) > 0) {
                    ?>
                        <img class="img img-thumbnail" src="<?php echo $Resim ?>" alt="<?php echo $Resim ?>">
                    <?php
                    }
                    ?>
                </div>
                <div class="col-md-8">
                    <?php echo substr($Icerik, 0, 240) ?><br>
                    <p class="text-right"><small>Oluşturma Tarihi: <?php echo $CTarihi; ?> - Güncelleme Tarihi: <?php echo $UTarihi; ?></small><br>
                    </p>
                </div>
            </div>
            <div class="row">
                <div class="col text-right">
                    <div class="btn-group" role="group" aria-label="Basic example">
                        <a href="index.php?pg=blog/blog_form&bid=<?php echo $BID; ?>" type="button" class="btn btn-warning">Edit</a>
                        <a href="blog/blog_guncelle.php?sil=<?php echo $BID; ?>" type="button" class="btn btn-danger">Sil</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php
}
$queryB->closeCursor();
?>