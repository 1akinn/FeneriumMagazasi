﻿<?php
if (isset($_GET["bid"])) { //UPDATE işlemi yapılacak
    $sqlB = "SELECT * FROM blog WHERE BID = " . $_GET["bid"];
    $queryB = $pdo->query($sqlB);
    $rowB = $queryB->fetch(PDO::FETCH_ASSOC);
    extract($rowB);
    //$rc = $queryB->rowCount();
    //echo "<h5> Kayhıt Sayısı " . $rc . "</h5>";
} else {  //INSERT işlemi yapılacak
    $ID = "";
    $Baslik = "";
    $Icerik = "";
}
?>
<div class="row">
    <div class="col-md-8 offset-md-2">
        <div class="card">
            <div class="card-header">
                <h4>Ürün Güncelleme</h4>
            </div>
            <div class="card-body">
                <form action="./blog/blog_guncelle.php" method="POST">
                    <div class="form-group" style="display:block">
                        <label for="ID">Ürün ID</label>
                        <input type="number" class="form-control" id="BID" name="BID" value="<?php echo @$BID; ?>" readonly>
                    </div>

                    <div class="form-group">
                        <label for="Baslik">Başlık</label>
                        <input type="text" class="form-control" id="Baslik" name="Baslik" value="<?php echo $Baslik; ?>">
                    </div>
                    <div class="form-group">
                        <label for="Icerik">İçerik</label>
                        <textarea name="Icerik" id="Icerik" rows="10" class="form-control"><?php echo $Icerik; ?></textarea>
                    </div>
                    <div class="form-group text-right">
                        <a href="./blog/blog_guncelle.php?sil=<?php echo @$ID; ?>" class="btn btn-danger mr-2">Sil</a>
                        <a href="./index.php?pg=blog/blog_form" class="btn btn-primary mr-2">Yeni</a>
                        <button type="submit" class="btn btn-success">Güncelle</button>
                    </div>

                </form>
                <?php
                if (@$BID > 0)
                    include "upload_form.php";
                ?>
            </div>
        </div>
    </div>
</div>
<div class="row mt-3">
    <div class="col-md-8 offset-md-2">
        <?php
        include "blog/blog_listele.php";
        ?>
    </div>
</div>