﻿

<?php
if (isset($_GET["bid"])) {
    $sqlB = "SELECT * FROM blog WHERE BID = " . $_GET["bid"];
    $queryB = $pdo->query($sqlB);
    $rowB = $queryB->fetch(PDO::FETCH_ASSOC);
    extract($rowB);
    $queryB->closeCursor();
}
?>

<div class="row">
     <div class="col-md-12 mt-4">
            <img style="width: 100%" src="<?php echo $Resim; ?>" />
        </div>
		


    <div class="col-md-12 mt-4">
        <h1><?php echo $Baslik ?></h1>
        
        <p>
            <?php echo $Icerik; ?>
        </p>
    </div>
</div>

<hr>

<div class="row">
    <div class="col">
        <?php
        include "blog/blog_main.php";
        ?>
    </div>
</div>