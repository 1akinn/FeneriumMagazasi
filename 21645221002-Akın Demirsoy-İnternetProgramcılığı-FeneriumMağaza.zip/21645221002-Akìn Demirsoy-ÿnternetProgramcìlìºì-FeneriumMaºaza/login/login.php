<?php
include "../dbconn.php";

if (isset($_POST["Email"]) && isset($_POST["Parola"])) {
    $email = trim($_POST["Email"]);
    $parola = trim($_POST["Parola"]);
    $sqlU = "SELECT * FROM uyeler WHERE Email = '{$email}' AND Parola = '{$parola}' ";
    $queryU = $pdo->query($sqlU);
    $rc = $queryU->rowCount();
    if ($rc == 1) {
        $rowU = $queryU->fetch(PDO::FETCH_ASSOC);
        //Eğer kullanıcı bulunursa UID numarasını
        //Session değişkeni olarak ata.
        $_SESSION["UID"] = $rowU["UID"];
    }
    $queryU->closeCursor();
} else {
    //Eğer formdan Email ev Parola gelmemişse
    //Oturumu kapat
    //$_SESSION["UID"] = NULL;
    unset($_SESSION["UID"]);
    echo "Oturum kapatıldı";
}
$pdo = NULL;
?>
<script>
    //window.location.replace("index.php");        
    history.back();
</script>