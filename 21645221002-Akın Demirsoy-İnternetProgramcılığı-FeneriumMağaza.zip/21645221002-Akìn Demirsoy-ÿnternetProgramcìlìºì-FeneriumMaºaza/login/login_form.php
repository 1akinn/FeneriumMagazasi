﻿<div class="row justify-content-center pt-5">
    <div class="col-6 card shadow-sm bg-light mb-5">
        <h4 class="pt-2">Oturum Aç</h4>
        <form action="login/login.php" method="post">
            <div class="form-group">
                <label for="Email">Email</label>
                <input type="email" id="Email" name="Email" class="form-control" value="koc@gmail.com">
            </div>
            <div class="form-group">
                <label for="Parola">Parola</label>
                <input type="password" id="Parola" name="Parola" class="form-control" value="fb">
            </div>
            <div class="form-group text-right">
                <input type="submit" class="btn btn-success" value="Oturum Aç">
            </div>
        </form>
    </div>
</div>