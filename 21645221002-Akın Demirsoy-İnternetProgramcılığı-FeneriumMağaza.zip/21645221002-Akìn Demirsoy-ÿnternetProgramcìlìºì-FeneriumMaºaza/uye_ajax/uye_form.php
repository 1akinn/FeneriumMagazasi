﻿<?php
include "../dbconn.php";
if (isset($_GET["UID"])) {
    $uid = $_GET["UID"];
    $sql = "SELECT * FROM uyeler WHERE UID = {$uid}";
    $row = $pdo->query($sql)->fetch();
    $ad = $row["Ad"];
    $soyad = $row["Soyad"];
    $email = $row["Email"];
    $parola = $row["Parola"];
    $yetki = $row["Yetki"];
} else {
    $uid = NULL;
    $ad = NULL;
    $soyad = NULL;
    $email = NULL;
    $parola = NULL;
    $yetki = NULL;
}
$pdo = NULL;
?>
<h5>Üye Formu</h5>
<form id="formUye" class="p-3" style="background-color:#eee">
    <div class="row mt-3">
        <div class="col">
            
            <input type="hidden" class="form-control" id="UID" name="UID" value="<?php echo $uid; ?>">
        </div>
    </div>
    <div class="row mt-3">
        <div class="col">
            <label for="">Ad</label>
            <input type="text" class="form-control" id="Ad" name="Ad" value="<?php echo $ad; ?>">
        </div>
    </div>
    <div class="row mt-3">
        <div class="col">
            <label for="">Soyad</label>
            <input type="text" class="form-control" id="Soyad" name="Soyad" value="<?php echo $soyad; ?>">
        </div>
    </div>
    <div class="row mt-3">
        <div class="col">
            <label for="">Email</label>
            <input type="text" class="form-control" id="Email" name="Email" value="<?php echo $email; ?>">
        </div>
    </div>
    <div class="row mt-3">
        <div class="col">
            <label for="">Parola</label>
            <input type="text" class="form-control" id="Parola" name="Parola" value="<?php echo $parola; ?>">
        </div>
    </div>
    <div class="row mt-3">
        <div class="col">
            <label for="">Yetki</label>
            <input type="text" class="form-control" id="Yetki" name="Yetki" value="<?php echo $yetki; ?>">
        </div>
    </div>
</form>
<div class="row mt-3">
    <div class="col" style="text-align:right">
        <button onClick="uyeForm()" class="btn btn-primary">Yeni</button>
        <button onclick="uyeGuncelle()" class="btn btn-success">Güncelle</button>
    </div>
</div>