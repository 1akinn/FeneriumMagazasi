﻿<?php
include "../dbconn.php";

if (isset($_GET["sil"]) && isset($_GET["UID"])) {
    $UID_del = trim($_GET["UID"]);
    $sql = "DELETE FROM uyeler WHERE UID = {$UID_del}";
    $query = $pdo->prepare($sql);
    $query->execute();
}

if (isset($_GET["update"])) {
    $UID_ = trim($_POST["UID"]);
    $ad_ = trim($_POST["Ad"]);
    $soyad_ = trim($_POST["Soyad"]);
    $email_ = trim($_POST["Email"]);
    $parola_ = trim($_POST["Parola"]);
    $yetki_ = trim($_POST["Yetki"]);

    if ($UID_ > 0) {
        //UIDATE: Güncelleme
        $sql = "UPDATE uyeler SET Ad = '{$ad_}', Soyad = '{$soyad_}', Email = '{$email_}',";
        $sql .= " Parola = '{$parola_}', Yetki = {$yetki_}";
        $sql .= " WHERE UID = {$UID_}";
    } else {
        //INSERT: Yeni Kayıt
        $sql = "INSERT INTO uyeler SET Ad = '{$ad_}', Soyad = '{$soyad_}', Email = '{$email_}',";
        $sql = $sql . " Parola = '{$parola_}', Yetki = {$yetki_}, UTarihi = '".date("Y-m-d H:i:s")."' ";
    }
    
    $query = $pdo->prepare($sql);
    $query->execute();
}

$pdo = NULL;
