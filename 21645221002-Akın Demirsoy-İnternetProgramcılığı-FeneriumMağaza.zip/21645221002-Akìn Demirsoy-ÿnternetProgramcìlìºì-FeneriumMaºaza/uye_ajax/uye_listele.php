<?php
include "../dbconn.php";
$ad = isset($_GET["Ad"]) ? $_GET["Ad"] :  NULL;
echo "Aranacak Kelime :" . $ad;
$sql = "SELECT * FROM uyeler WHERE 1 AND Ad LIKE '{$ad}%' OR Soyad LIKE '{$ad}%'";
//echo "<h5> SQL :" . $sql . "</h5>";
$query = $pdo->prepare($sql);
$query->execute();
$pdo = NULL;
?>
<h5>Üyeler Listesi</h5>
<table class="table table-bordered table-striped table-hover bg-white">
    <thead class="thead-dark">
        <tr>
            <th>UID</th>
            <th>Ad Soyad</th>
            <th>Email</th>
            <th>Parola</th>
            <th>İşlem</th>
        </tr>
    </thead>
    <?php
    foreach ($query as $row) {
        $UID = $row["UID"];
        //$linkU = "<a href='index.php?pg=uye_form&uid=$UID'>Edit</a>";
    ?>
        <tr>
            <td width="20"><?php echo $row["UID"]; ?></td>
            <td><?php echo $row["Ad"] . " " . $row["Soyad"]; ?></td>
            <td><?php echo $row["Email"]; ?></td>
            <td><?php echo $row["Parola"]; ?></td>
            <td width="130">
                <button onClick="uyeForm(<?php echo $UID; ?>)" class="btn btn-sm btn-warning">Düzenle</button>
                <button onClick="uyeSil(<?php echo $UID; ?>)" class="btn btn-sm btn-danger">Sil</button>
            </td>
        </tr>
    <?php
    }
    $query->closeCursor();
    ?>
</table>