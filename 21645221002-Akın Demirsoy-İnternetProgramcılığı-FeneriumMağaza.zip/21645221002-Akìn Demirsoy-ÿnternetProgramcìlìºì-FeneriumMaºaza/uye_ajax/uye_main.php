﻿<script>
    $(document).ready(function() {
        $("#divSol").load("uye_ajax/uye_form.php");
        $("#divSag").load("uye_ajax/uye_listele.php");

        $("#txtAra").keyup(function() {
            var ad = $(this).val();
            //alert("ad :" + ad);
            $("#divSag").load("uye_ajax/uye_listele.php?Ad=" + ad);
        });

    });

    function uyeForm(uid = null) {
        if (uid != null) $("#divSol").load("uye_ajax/uye_form.php?UID=" + uid);
        else {
            $.ajax({
            type: "POST",
            url: "uye_ajax/uye_guncelle.php?update=1",
            cache: false,
            data: $("#formUye").serialize(),
            success: function(sonuc) {
                ad = $("#txtAra").val();
                $("#divSag").load("uye_ajax/uye_listele.php?Ad=" + ad);
                $("#divBilgi").html(sonuc);
            }
        });

        }
    }

    function uyeSil(uid = null) {
        if (confirm("Silmek İstediğinize emin misiniz?") == true) {
            $("#divBilgi").load("uye_ajax/uye_guncelle.php?sil=1&UID=" + uid);
            $("#divSag").load("uye_ajax/uye_listele.php");
            alert("kayıt silindi");
        } else {
            alert("İptal edildi");
        }
    }

    function uyeGuncelle() {
        $.ajax({
            type: "POST",
            url: "uye_ajax/uye_guncelle.php?update=1",
            cache: false,
            data: $("#formUye").serialize(),
            success: function(sonuc) {
                ad = $("#txtAra").val();
                $("#divSag").load("uye_ajax/uye_listele.php?Ad=" + ad);
                $("#divBilgi").html(sonuc);
            }
        });
    }
</script>
<div class="row">
    <div class="col-md-4">
        <h3>Ajax Üye Uygulaması</h3>
    </div>
    <div class="col-md-8">
        <input type="text" id="txtAra" class="form-control" placeholder="aranacak kelime">
    </div>
</div>
<div class="row">
    <div class="col" id=divBilgi></div>
</div>
<div class="row mt-3 mb-3">
    <div id="divSol" class="col-md-4 pb-3">

    </div>
    <div id="divSag" class="col-md-8 pb-3">

    </div>
</div>