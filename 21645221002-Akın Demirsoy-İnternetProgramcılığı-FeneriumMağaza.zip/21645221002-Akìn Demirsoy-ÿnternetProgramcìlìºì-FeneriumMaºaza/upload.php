<?php
$target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

// Yüklenen dosyanın mime type bilgisi kontrol ediliyor.
if (isset($_POST["submit"])) {
    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if ($check !== false) {
        echo "Dosya uygun - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "<h6>Hata, Bir dosya seçin!</h6>";
        $uploadOk = 0;
    }
}

// Dosyanın resim formatında olup olmadığı kontrol ediliyor.
if (
    $imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
    && $imageFileType != "gif"
) {
    echo "<h6>Hata, sadece JPG, JPEG, PNG & GIF dosyaları kabol edilir.</h6>";
    $uploadOk = 0;
}

// Aynı adda sahi başka bir dosyanın var olup olmadığı kontrol eidliyor.
if (file_exists($target_file)) {
    echo "<h6>Hata, Dosya Zaten var!</h6>";
    $uploadOk = 0;
}

if ($uploadOk == 1) {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        echo "The file " . htmlspecialchars(basename($_FILES["fileToUpload"]["name"])) . " yüklendi.";
        $table =  $_POST["table"];
        $column =  $_POST["column"];
        $BID = $_POST["BID"];
        //Eğer yükleme sırasında bir hata meydana gelmezse dosya tabbloya kaydediliyor.
        include "dbconn.php";
        $sqlG = "UPDATE {$table} SET {$column} = '{$target_file}' WHERE BID = " . $BID;
        $queryG = $pdo->prepare($sqlG);
        $queryG->execute();
        echo "<br>Sorgu :" . $sqlG;
        $pdo = NULL;
    } else {
        echo "Yükleme sırasında bir hata oluştu.";
    }
}
?>
<script>
    window.history.back();
</script>