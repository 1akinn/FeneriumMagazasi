-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1:3306
-- Üretim Zamanı: 03 Haz 2022, 14:36:07
-- Sunucu sürümü: 8.0.21
-- PHP Sürümü: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `21645221002_db`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `blog`
--

DROP TABLE IF EXISTS `blog`;
CREATE TABLE IF NOT EXISTS `blog` (
  `BID` int NOT NULL,
  `UID` int DEFAULT NULL,
  `Baslik` varchar(255) DEFAULT NULL,
  `Icerik` text,
  `Resim` varchar(255) DEFAULT NULL,
  `CTarihi` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `UTarihi` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `blog`
--

INSERT INTO `blog` (`BID`, `UID`, `Baslik`, `Icerik`, `Resim`, `CTarihi`, `UTarihi`) VALUES
(1, 1, 'Kadın Lacivert Tribün Taşlı Logo Tshirt', '• %100 Pamuk • 30C de yıkanabilir. • Ağartıcı kullanılmaz. • Santrifüjlü makinede kurutulmaz. • Ilık ütü yapınız. • Kuru temizleme yapılmaz.', 'uploads/fb7.jpg', '2021-03-22 18:48:46', '2021-03-28 14:03:23'),
(2, 1, 'Erkek Tribün 1907 Biye Detaylı Sweatshirt', '•%74 Polyester, %28 Pamuk •30C de yıkanabilir. •Ağartıcı kullanılmaz. •Santrifüjlü makinede kurutulmaz. •Ilık ütü yapınız. •Kuru temizleme yapılmaz.', 'uploads/fb8.jpg', '2021-03-28 13:48:04', NULL),
(3, 1, 'Fenerbahçe 2021 Lacivert Forma', '• %100 Polyester • Baskıyı ütülemeyiniz. • Renklilere özel deterjan kullanınız. • Tersten yıkayıp ütüleyiniz. • Benzer renklerle birlikte yıkayınız.', 'uploads/fb4.jpg', '2021-03-28 13:49:00', '2021-03-28 14:02:20'),
(4, 1, 'Puma Fenerbahçe Baskılı Lacivert Tshirt', '• %100 Pamuk • 30C de yıkanabilir. • Ağartıcı kullanılmaz. • Santrifüjlü makinede kurutulmaz. • Ilık ütü yapınız. • Kuru temizleme yapılmaz.', 'uploads/fb5.jpg', '2021-03-29 11:22:31', '2021-03-29 11:22:57'),
(5, 1, 'Fenerbahçe 2021 Çubuklu Forma', '• %100 Polyester • Baskıyı ütülemeyiniz. • Renklilere özel deterjan kullanınız. • Tersten yıkayıp ütüleyiniz. • Benzer renklerle birlikte yıkayınız.', 'uploads/fb2.jpg', '2021-03-29 11:26:13', NULL),
(6, 1, 'Erkek Sarı Lacivert Kolej Çizgili FB Tshirt', '• %100 Pamuk • 30C de yıkanabilir. • Ağartıcı kullanılmaz. • Santrifüjlü makinede kurutulmaz. • Ilık ütü yapınız. • Kuru temizleme yapılmaz.', 'uploads/fb6.jpg', '2021-03-29 11:26:40', '2021-04-12 14:24:10'),
(7, 1, 'Fenerbahçe 2021 Gri Forma', '• %100 Polyester • Baskıyı ütülemeyiniz. • Renklilere özel deterjan kullanınız. • Tersten yıkayıp ütüleyiniz. • Benzer renklerle birlikte yıkayınız.', 'uploads/fb3.jpg', '2021-04-12 14:28:42', '2021-04-12 14:31:49'),
(8, 1, 'Erkek Beyaz Tribün Palamut Nakış Tshirt', '• %100 Pamuk • 30C de yıkanabilir. • Ağartıcı kullanılmaz. • Santrifüjlü makinede kurutulmaz. • Ilık ütü yapınız. • Kuru temizleme yapılmaz.', 'uploads/fb1.jpg', '2021-03-29 11:26:40', '2021-04-12 14:24:10');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `uyeler`
--

DROP TABLE IF EXISTS `uyeler`;
CREATE TABLE IF NOT EXISTS `uyeler` (
  `UID` int NOT NULL AUTO_INCREMENT,
  `Ad` varchar(24) DEFAULT NULL,
  `Soyad` varchar(24) DEFAULT NULL,
  `Email` varchar(254) DEFAULT NULL,
  `Parola` varchar(254) DEFAULT NULL,
  `UTarihi` datetime DEFAULT CURRENT_TIMESTAMP,
  `Yetki` int DEFAULT '2',
  `Aciklama` text,
  PRIMARY KEY (`UID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `uyeler`
--

INSERT INTO `uyeler` (`UID`, `Ad`, `Soyad`, `Email`, `Parola`, `UTarihi`, `Yetki`, `Aciklama`) VALUES
(1, 'ALİ', 'KOÇ', 'koc@gmail.com', 'fb', '2021-04-12 14:00:02', 2, NULL),
(2, 'AKIN', 'DEMIRSOY', 'akin@gmail.com', '123', '2022-06-03 12:10:48', 74, NULL),
(3, 'ACUN', 'ILICALI', 'acun@gmail.com', 'survivor', '2022-06-03 12:11:17', 1907, NULL),
(4, 'BERFİN', 'TURHAK', 'berfin@gmail.com', '5467653', '2022-06-03 12:12:23', 123, NULL),
(5, 'SELIN', 'TAY', 'selin@gmail.com', '645345', '2022-06-03 12:12:48', 213, NULL),
(6, 'ARDA', 'AKSOY', 'arda@gmail.com', '12353435', '2022-06-03 12:13:07', 123, NULL),
(7, 'GURKAN', 'BOZ', 'gurkan@gmail.com', '6524324', '2022-06-03 12:13:37', 44, NULL);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
