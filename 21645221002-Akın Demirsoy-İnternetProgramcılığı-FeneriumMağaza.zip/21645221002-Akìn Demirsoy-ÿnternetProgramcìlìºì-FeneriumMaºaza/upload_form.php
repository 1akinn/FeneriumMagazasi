<h5>Resim Yükle</h5>
<form action="upload.php" method="post" enctype="multipart/form-data">
    <div class="form-group">
        <input type="hidden" id="table" name="table" value="blog">
        <input type="hidden" id="column" name="column" value="Resim">
        <input type="hidden" id="BID" name="BID" value="<?php echo $BID; ?>" readonly>
        <input type="file" name="fileToUpload" id="fileToUpload" class="form-control">
    </div>
    <div class="form-group text-right">
        <input type="submit" value="Upload Image" name="submit" class="btn btn-outline-primary">
    </div>
</form>