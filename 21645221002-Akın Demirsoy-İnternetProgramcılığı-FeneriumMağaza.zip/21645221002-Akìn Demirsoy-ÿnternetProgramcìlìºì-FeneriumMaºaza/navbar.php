﻿<nav class="navbar navbar-expand-sm bg-dark navbar-dark">

<a href="index.php"><img src="uploads/fb.png" width="40" height="40" alt="Web Sitesi Logosu" />
    <a class="navbar-brand"href="index.php">&emsp;Fenerium</a>

    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarText">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
                <a class="nav-link" href="index.php">Ana Sayfa<span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="index.php?pg=uye_ajax/uye_main">Müşteri Ekle</a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="index.php?pg=blog/blog_form">Ürün Güncelle</a>
            </li>
        </ul>
        <span class="navbar-text">
            <?php
            if ($UID_ > 0) {
                echo $UID_ . " " . $ad_soyad . "&nbsp;";
                echo "<a href='login/login.php'>Oturumu Kapat</a>";
            } else {
                echo "<a href='index.php?pg=login/login.php'>Oturumu Aç</a>";
            }
            ?>
        </span>
    </div>
</nav>