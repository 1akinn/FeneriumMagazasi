﻿<?php
include "dbconn.php";
include "head.php";

$page = isset($_GET["pg"]) ? $_GET["pg"] : "blog/blog_main";
$page_inc = $page . ".php";

if ($UID_ ==  0)
    $page_inc = "login/login_form.php";

//echo "Açılacak Sayfa :" . $page_inc;
?>
<html>

<head>
    <meta charset="utf-8" />
</head>

<body>
    <?php include "navbar.php"; ?>
    <div class="container pb-5">
        <div class="row pt-3">
            <div class="col">
                <?php
                include $page_inc;
                ?>
            </div>
        </div>       
    </div>
<footer>    
    Tüm Hakları Saklıdır © Fenerium 2022    
</footer>  
</body>

</html>
<?php
$pdo = NULL;
?>