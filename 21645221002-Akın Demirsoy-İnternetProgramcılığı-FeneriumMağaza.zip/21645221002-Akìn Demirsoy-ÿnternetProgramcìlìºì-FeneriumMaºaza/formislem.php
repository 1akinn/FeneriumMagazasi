<html>
<body>

<?php
   echo 'Ad�: ' . htmlspecialchars($_POST['adi']);
?>

</body>
</html>